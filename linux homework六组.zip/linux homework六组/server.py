#导入了必要的python标准库模块
import sys  # 标准库模块
import time  # 时间模块
import socket  # 套接字模块
import threading # 线程模块
from PyQt5 import QtCore, QtWidgets # 导入窗口部件模块
from PyQt5.QtWidgets import QMainWindow, QApplication # 导入窗口模块
from PyQt5.QtCore import QThread, pyqtSignal, QDateTime, QObject # 导入时间模块


class BackendThread(QObject):   # 定义这个类用来实时更新显示收到的消息
    # 通过类成员对象定义信号
    update_date = pyqtSignal(str) # 定义构造函数


    # 处理业务逻辑
    def run(self): 
        """
        后台线程的主要运行函数，负责实时更新并发送当前日期和时间。

        该函数会不断循环，每秒获取一次当前日期和时间，并通过信号机制将其发送出去。
        这样可以确保前端界面能够实时显示最新的时间信息。
        """
        while True:
            # 获取当前日期和时间
            data = QDateTime.currentDateTime()
            # 将日期和时间格式化为字符串
            currTime = data.toString("yyyy-MM-dd hh:mm:ss")
            # 发送更新后的日期和时间
            self.update_date.emit(str(currTime)+'\n') 
            # 等待1秒，避免频繁更新
            time.sleep(10)
#定义一个类用于设置服务器图形界面和处理相关的业务逻辑
class Ui_Dialog(object):
    s = socket.socket()#服务器套接字对象
    c = None#用于存储客户端
    msg_send = '' # 存储发送的消息
    msg_rec = '' # 存储接受的消息
    def setupUi(self, Dialog):# 定义设置界面的方法
        """
        初始化并设置对话框的用户界面。

        参数:
        - Dialog: 对话框对象，用于设置界面。

        该方法会设置对话框的名称、大小、布局和各种控件，如标签、文本框、按钮等。
        它还会将信号与槽连接起来，以便在用户与界面交互时执行相应的操作。
        """
        Dialog.setObjectName("Dialog") # 窗口名称
        Dialog.resize(808, 320) # 窗口大小
        self.layoutWidget = QtWidgets.QWidget(Dialog)# 窗口部件
        self.layoutWidget.setGeometry(QtCore.QRect(30, 20, 753, 272)) # 窗口部件大小
        self.layoutWidget.setObjectName("layoutWidget") # 窗口部件名称
        self.verticalLayout = QtWidgets.QVBoxLayout(self.layoutWidget) # 窗口部件布局
        self.verticalLayout.setContentsMargins(0, 0, 0, 0) # 窗口部件大小
        self.verticalLayout.setObjectName("verticalLayout") # 窗口部件名称
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout() # 窗口部件布局
        self.horizontalLayout_4.setObjectName("horizontalLayout_4") # 窗口部件布局
        self.horizontalLayout = QtWidgets.QHBoxLayout() # 窗口部件布局
        self.horizontalLayout.setObjectName("horizontalLayout") # 窗口部件布局
        self.label = QtWidgets.QLabel(self.layoutWidget) #初始化一个 QLabel 控件，用于显示文本信息
        self.label.setObjectName("label")# 设置标签的对象名称，用于在 Qt 框架中标识和引用这个标签
        self.horizontalLayout.addWidget(self.label) # 水平布局
        self.lineEdit = QtWidgets.QLineEdit(self.layoutWidget) # 文本框
        self.lineEdit.setObjectName("lineEdit") # 文本框
        self.horizontalLayout.addWidget(self.lineEdit) # 水平布局
        self.horizontalLayout_4.addLayout(self.horizontalLayout) # 水平布局
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout() # 窗口部件布局
        self.horizontalLayout_2.setObjectName("horizontalLayout_2") # 窗口部件布局
        self.label_2 = QtWidgets.QLabel(self.layoutWidget)  # 初始化一个 QLabel 控件，用于显示文本信息
        self.label_2.setObjectName("label_2")  # 设置标签的对象名称，用于在 Qt 框架中标识和引用这个标签
        self.horizontalLayout_2.addWidget(self.label_2) # 水平布局
        self.lineEdit_2 = QtWidgets.QLineEdit(self.layoutWidget) # 文本框
        self.lineEdit_2.setObjectName("lineEdit_2") # 文本框
        self.horizontalLayout_2.addWidget(self.lineEdit_2) # 水平布局
        self.horizontalLayout_4.addLayout(self.horizontalLayout_2) # 水平布局
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout() # 窗口部件布局
        self.horizontalLayout_3.setObjectName("horizontalLayout_3") # 水平布局
        self.pushButton_4 = QtWidgets.QPushButton(self.layoutWidget) # 按钮
        self.pushButton_4.setObjectName("pushButton_4") # 按钮
        self.horizontalLayout_3.addWidget(self.pushButton_4) # 水平布局
        self.pushButton_5 = QtWidgets.QPushButton(self.layoutWidget)  # 初始化一个 QPushButton 控件，用于触发某个操作
        self.pushButton_5.setObjectName("pushButton_5") # 按钮
        self.horizontalLayout_3.addWidget(self.pushButton_5) # 水平布局
        self.horizontalLayout_4.addLayout(self.horizontalLayout_3) # 水平布局
        self.verticalLayout.addLayout(self.horizontalLayout_4) # 水平布局
        self.horizontalLayout_5 = QtWidgets.QHBoxLayout() # 窗口部件布局
        self.horizontalLayout_5.setObjectName("horizontalLayout_5") # 水平布局
        self.label_3 = QtWidgets.QLabel(self.layoutWidget) #初始化一个 QLabel 控件，用于显示文本信息
        self.label_3.setObjectName("label_3")  # 设置标签的对象名称，用于在 Qt 框架中标识和引用这个标签
        self.horizontalLayout_5.addWidget(self.label_3)# 水平布局
        self.lineEdit_3 = QtWidgets.QLineEdit(self.layoutWidget) # 文本框
        self.lineEdit_3.setObjectName("lineEdit_3") # 文本框
        self.horizontalLayout_5.addWidget(self.lineEdit_3) # 水平布局
        self.pushButton_3 = QtWidgets.QPushButton(self.layoutWidget) # 按钮
        self.pushButton_3.setObjectName("pushButton_3") # 按钮
        self.horizontalLayout_5.addWidget(self.pushButton_3) # 水平布局
        self.verticalLayout.addLayout(self.horizontalLayout_5)  # 水平布局
        self.horizontalLayout_6 = QtWidgets.QHBoxLayout()  # 窗口部件布局
        self.horizontalLayout_6.setObjectName("horizontalLayout_6") # 水平布局
        self.label_4 = QtWidgets.QLabel(self.layoutWidget)   # 初始化一个 QLabel 控件，用于显示文本信息
        self.label_4.setContextMenuPolicy(QtCore.Qt.DefaultContextMenu) # 上下文菜单策略
        self.label_4.setAutoFillBackground(False) # 自动填充背景
        self.label_4.setTextFormat(QtCore.Qt.AutoText) # 文本格式
        self.label_4.setWordWrap(True) # 自动换行
        self.label_4.setOpenExternalLinks(False) # 外部链接
        self.label_4.setObjectName("label_4")  # 设置标签的对象名称，用于在 Qt 框架中标识和引用这个标签
        self.horizontalLayout_6.addWidget(self.label_4) # 水平布局
        self.textBrowser = QtWidgets.QTextBrowser(self.layoutWidget) # 文本浏览器
        self.textBrowser.setObjectName("textBrowser") # 文本浏览器
        self.horizontalLayout_6.addWidget(self.textBrowser) # 水平布局
        self.label_5 = QtWidgets.QLabel(self.layoutWidget) # 初始化一个 QLabel 控件，用于显示文本信息
        self.label_5.setTextFormat(QtCore.Qt.AutoText) # 文本格式
        self.label_5.setWordWrap(True) # 自动换行
        self.label_5.setObjectName("label_5") # 设置标签的对象名称，用于在 Qt 框架中标识和引用这个标签
        self.horizontalLayout_6.addWidget(self.label_5) # 水平布局
        self.textBrowser_2 = QtWidgets.QTextBrowser(self.layoutWidget) # 文本浏览器
        self.textBrowser_2.setObjectName("textBrowser_2") # 文本浏览器
        self.horizontalLayout_6.addWidget(self.textBrowser_2) # 水平布局
        self.verticalLayout.addLayout(self.horizontalLayout_6) # 水平布局

        self.retranslateUi(Dialog) # 显示内容
        QtCore.QMetaObject.connectSlotsByName(Dialog) # 绑定信号和槽
    def retranslateUi(self, Dialog): # 定义显示内容的方法
        """
        初始化并设置对话框的用户界面。

        参数:
        - Dialog: 对话框对象，用于设置界面。

        该方法会设置对话框的名称、大小、布局和各种控件，如标签、文本框、按钮等。
        它还会将信号与槽连接起来，以便在用户与界面交互时执行相应的操作。
        """
        self.s = socket.socket() # 服务器套接字对象
        _translate = QtCore.QCoreApplication.translate # 翻译
        Dialog.setWindowTitle(_translate("Dialog", "服务器")) # 窗口名称
        self.label.setText(_translate("Dialog", "服务器名称：")) # 设置标签的文本内容，用于在界面上显示服务器名称的提示信息
        self.label_2.setText(_translate("Dialog", "服务器端口：")) # 设置标签的文本内容，用于在界面上显示服务器端口的提示信息
        self.pushButton_4.setText(_translate("Dialog", "监听"))# 按钮
        self.pushButton_5.setText(_translate("Dialog", "断开"))# 按钮
        self.label_3.setText(_translate("Dialog", "消息：")) # 设置标签的文本内容，用于在界面上显示消息的提示信息
        self.pushButton_3.setText(_translate("Dialog", "发送"))# 按钮
        self.label_4.setText(_translate("Dialog", "发送的消息"))  # 设置标签的文本内容，用于在界面上显示发送的消息的提示信息
        self.label_5.setText(_translate("Dialog", "接受的消息")) # 设置标签的文本内容，用于在界面上显示接受的消息的提示信息
        self.lineEdit.setText("127.0.0.1") # 服务器地址
        self.lineEdit_2.setText("21567") # 服务器端口
        self.pushButton_3.clicked.connect(self.send_button) # 发送按钮
        self.pushButton_4.clicked.connect(self.listen_button)# 监听按钮
        self.pushButton_5.clicked.connect(self.break_button)# 断开按钮

        # 调用刚才的自定义类
        self.backend = BackendThread()# 自定义类
        self.backend.update_date.connect(self.handleDisplay)    # 连接信号事件
        self.thread = QThread()     # 创建进程
        self.backend.moveToThread(self.thread) # 移动到线程
        self.thread.started.connect(self.backend.run) # 开始线程
        self.thread.start()# 开始进程

    def listen_button(self):        # 监听按钮
        """
        监听按钮的槽函数，用于启动服务器的监听功能。

        该方法会获取用户在界面上输入的服务器地址和端口号，然后绑定到服务器套接字上。
        接着，它会启动一个线程来处理客户端的连接请求。
        """
        add1 = self.lineEdit.text() # 服务器地址
        add2 = self.lineEdit_2.text() # 服务器端口
        self.s.bind((add1, int(add2))) # 绑定地址和端口
        self.s.listen() # 监听
        print('正在监听。。。')# 打印
        t1 = threading.Thread(target=self.accept_socket)# 线程
        t1.start()# 开始线程

    def send_button(self):      # 发送按钮
        """
        发送按钮的槽函数，用于向客户端发送消息。

        该方法会获取用户在界面上输入的消息内容，然后将其编码为 GB2312 格式，并通过服务器套接字发送给客户端。
        发送成功后，它会将发送的消息显示在界面上的文本浏览器中，并清空输入框。
        """
        # 获取当前时间和用户输入的消息内容
        MSG = '[' + time.ctime() + ']:' + self.lineEdit_3.text() + '\n'
        # 将消息编码为 GB2312 格式并发送
        self.c.send(MSG.encode('GB2312'))
        # 打印发送的消息
        print('已发送:', MSG)
        # 将发送的消息添加到显示消息的文本框中
        self.msg_send += MSG
        # 更新文本浏览器的内容
        self.textBrowser.setText(self.msg_send)
        # 清空输入框
        self.lineEdit_3.setText('')



    def break_button(self):     # 断开按钮
        """
        断开按钮的槽函数，用于关闭服务器的套接字连接。

        该方法会调用服务器套接字的 `close()` 方法，关闭服务器的监听端口，
        从而停止接收客户端的连接请求。
        """
        self.s.close()

    def accept_socket(self):     # 接收socket连接
        """
        接收socket连接的方法，用于处理客户端的连接请求。

        该方法会不断循环，等待客户端的连接。一旦接收到连接，它会打印一条消息表示已连接，
        并启动一个新线程来处理接收消息的任务。
        """
        while 1:
            print('等待连接中。。。')
            # 接收连接，返回客户端套接字和地址
            self.c, addr = self.s.accept()
            print('已连接')
            break
        # 创建一个新线程来处理接收消息的任务
        t2 = threading.Thread(target=self.rec_msg)
        t2.start()# 开始线程

    def handleDisplay(self, data):      # 显示收到的信息
        """
        处理并显示接收到的消息。

        参数:
        - data: 接收到的消息数据。

        该方法会将接收到的消息添加到显示消息的文本框中，并更新文本浏览器的内容。
        """
        # 将接收到的消息添加到显示消息的文本框中
        self.msg_rec += data
        # 更新文本浏览器的内容
        self.textBrowser_2.setText(self.msg_rec)

    def rec_msg(self):      # 接受消息
        """
        接收消息的方法，用于处理客户端发送的消息。

        该方法会不断循环，等待客户端发送消息。一旦接收到消息，它会将消息解码为 GB2312 格式，
        并将其添加到显示消息的文本框中。同时，它会打印接收到的消息。
        """
        while 1:
            print('等待接受消息中。。。') # 等待接受消息
            msg = self.c.recv(1024).decode('GB2312') # 接收消息
            # self.c.send('1s'.encode("GB2312"))
            print('收到消息', msg) # 显示收到的消息
            self.msg_rec += msg # 存储收到的消息
            # self.textBrowser_2.setText(self.msg_rec)
            # QApplication.processEvents()
            print(self.msg_rec) # 显示收到的消息
            # time.sleep(2)

 
if __name__ == '__main__': #主函数
    app = QApplication(sys.argv) # 实例化窗口
    MainWindow = QMainWindow() # 实例化窗口
    ui = Ui_Dialog() # 实例化窗口
    ui.setupUi(MainWindow) # 调用方法
    MainWindow.show() # 显示窗口
    sys.exit(app.exec_()) # 退出程序